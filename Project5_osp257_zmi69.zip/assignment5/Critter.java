/*
 * CRITTERS Critter.java
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 0
 * Fall 2021
 */

package assignment5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.Circle;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;

import java.security.acl.Group;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import assignment5.Clover;
import assignment5.Critter;
import assignment5.InvalidCritterException;
import assignment5.Params;

/*
 * See the PDF for descriptions of the methods and fields in this
 * class.
 * You may add fields, methods or inner classes to Critter ONLY
 * if you make your additions private; no new public, protected or
 * default-package code or data can be added to Critter.
 */

public abstract class Critter {

    /* START --- NEW FOR PROJECT 5 */
    public enum CritterShape {
        CIRCLE,
        SQUARE,
        TRIANGLE,
        DIAMOND,
        STAR
    }

    /* the default color is white, which I hope makes critters invisible by default
     * If you change the background color of your View component, then update the default
     * color to be the same as you background
     *
     * critters must override at least one of the following three methods, it is not
     * proper for critters to remain invisible in the view
     *
     * If a critter only overrides the outline color, then it will look like a non-filled
     * shape, at least, that's the intent. You can edit these default methods however you
     * need to, but please preserve that intent as you implement them.
     */
    public javafx.scene.paint.Color viewColor() {
        return javafx.scene.paint.Color.WHITE;
    }

    public javafx.scene.paint.Color viewOutlineColor() {
        return viewColor();
    }

    public javafx.scene.paint.Color viewFillColor() {
        return viewColor();
    }

    public abstract CritterShape viewShape();

    protected final String look(int direction, boolean steps) {
    	int checkx = 0;
    	int checky = 0;
    	int numtoadd;
        if(steps == false) {
        	numtoadd = 1;}
        else {
        	numtoadd = 2;
        }
        	if(direction != 2 && direction != 6) {
        		if((direction == 0) || (direction == 1) || (direction == 7)) {
        			checkx=x_coord+numtoadd;
        		}
        		
        		else if((direction > 2) && (direction < 6)) {
        			checkx=x_coord-numtoadd;
        		}
        	}
        	
        	if(direction != 0 && direction != 4) {
        		if((direction > 0) && (direction < 4)) {
        			checky=y_coord-numtoadd;
        		}
        		
        		else if((direction > 4) && (direction <= 7)) {
        			checky=y_coord+numtoadd;
        		}
        	}
        	
        	energy = getEnergy() - Params.WALK_ENERGY_COST;
        	
        	//coordinates wraps around if necessary
        	if(checkx < 0) {
        		checkx = (Params.WORLD_WIDTH  + checkx);
        	}
        	
        	if(checky < 0) {
        		checky = (Params.WORLD_HEIGHT + checky);
        	}
        	
        	checkx = checkx % Params.WORLD_WIDTH;
        	checky = checky % Params.WORLD_HEIGHT;
        	
        	for(Critter i : beforeMoving) {//checks against critters positions before the timestep
        		if(i.x_coord == checkx && i.y_coord == checky) {
        			energy = energy - Params.LOOK_ENERGY_COST;
        			return i.toString();
        		}
        	}
        	energy = energy - Params.LOOK_ENERGY_COST;
        	return null;
        }

        
    

    public static String runStats(List<Critter> critters) {
    	String runStatsStr = "" + critters.size() + " critters as follows -- ";
        
    	Map<String, Integer> critterCount = new HashMap<String, Integer>();
        
    	for (Critter crit : critters) {
            String critString = crit.toString();
            
            critterCount.put(critString,
            		critterCount.getOrDefault(critString, 0) + 1);
        }
        
        String prefix = "";
        
        for (String s : critterCount.keySet()) {
        	runStatsStr += prefix + s + ":" + critterCount.get(s);
            prefix = ", ";
        }
        
        return runStatsStr;
    }


    public static void displayWorld(Object pane) {
        // TODO Implement this method
    }

	/* END --- NEW FOR PROJECT 5
			rest is unchanged from Project 4 */

    private int energy = 0;

    private int x_coord;
    private int y_coord;

	public String name;

	public boolean alive;

    private static List<Critter> population = new ArrayList<Critter>();
    private static List<Critter> beforeMoving = new ArrayList<Critter>();
    private static List<Critter> babies = new ArrayList<Critter>();
    private static List<Critter> hasMoved = new ArrayList<Critter>();

    /* Gets the package name.  This assumes that Critter and its
     * subclasses are all in the same package. */
    private static String myPackage;

    static {
        myPackage = Critter.class.getPackage().toString().split(" ")[1];
    }

    private static Random rand = new Random();

    public static int getRandomInt(int max) {
        return rand.nextInt(max);
    }

    public static void setSeed(long new_seed) {
        rand = new Random(new_seed);
    }

    /**
     * create and initialize a Critter subclass.
     * critter_class_name must be the qualified name of a concrete
     * subclass of Critter, if not, an InvalidCritterException must be
     * thrown.
     *
     * @param critter_class_name
     * @throws InvalidCritterException
     */
    public static void createCritter(String critter_class_name)
            throws InvalidCritterException {   		
        		critter_class_name = myPackage + "." + critter_class_name;
        		
        		try {
    				Critter critter = (Critter) Class.forName(critter_class_name).newInstance();
    				critter.energy = Params.START_ENERGY;
    				critter.alive = true;
    				critter.name = critter.toString();
    				critter.x_coord = getRandomInt(Params.WORLD_WIDTH);
    				critter.y_coord = getRandomInt(Params.WORLD_HEIGHT);
    				population.add(critter);
    			} catch (Exception e) {
    				throw new InvalidCritterException(critter_class_name);
    			}     		
        }

        /**
         * Gets a list of critters of a specific type.
         *
         * @param critter_class_name What kind of Critter is to be listed.
         *        Unqualified class name.
         * @return List of Critters.
         * @throws InvalidCritterException
         */
        public static List<Critter> getInstances(String critter_class_name) 
        		throws InvalidCritterException {
        	  		List<Critter> instances = new ArrayList<Critter>();
        	  		critter_class_name = myPackage + "." + critter_class_name;
            		
            		try {
        				Object critter = Class.forName(critter_class_name).newInstance();
        				
        				for(Critter i : population) {
        		    		if(i.getClass().equals(critter.getClass())) {
        		    			instances.add(i);
        		    		}
        		    	}
        			} catch (Exception e) {
        				throw new InvalidCritterException(critter_class_name);
        			} 
        	
            		return instances;
        }

        /**
         * Clear the world of all critters, dead and alive
         */
        public static void clearWorld() {
        	population.clear();
        }

        /**
         * simulates one time step for every Critter in the critter collection.
         *
         * @param nothing.
         * @return nothing.
         */
        public static void worldTimeStep() {
        	for(Critter i: population) {//saves current location for look method
        		beforeMoving.add(i);
        	}
        	for(Critter i: population) {//calls doTimeStep for every critter, if they have moved, marks them in moved array
    	    	int savex = i.x_coord;
    	    	int savey = i.y_coord;
    	    	
    	    	i.doTimeStep();
        		
    	    	if(i.x_coord != savex || i.y_coord != savey) {
        			hasMoved.add(i);
        		}
    	    	
        		if(i.energy <= 0) {
        			i.alive = false;
        		}
        	}
        	beforeMoving.clear();
        	for(Critter i : population) {//changes all locations to most current for look method
        		beforeMoving.add(i);
        	}
        	
        	for(int i = 0; i < population.size() - 1; i++) {// causes only one encounter if two different critters are in the same location
        		for (int j = i + 1; j < population.size(); j++) {
        			int ix_coord = population.get(i).x_coord;
        			int jx_coord = population.get(j).x_coord;
        			int iy_coord = population.get(i).y_coord;
        			int jy_coord = population.get(j).y_coord;
        			boolean ialive = population.get(i).alive;
        			boolean jalive = population.get(j).alive;
        			
        			if((ix_coord == jx_coord) && (iy_coord == jy_coord) && (ialive == true && jalive == true)) {
        				doEncounters(population.get(i), population.get(j));
        			}
        		}
        	}
        	
        	
        	ArrayList<Critter> dead = new ArrayList<Critter>();
        	for(Critter i : population) {// subtracts rest energy and removes dead critters
        		
        		if(i.alive == true) {
        			i.energy = i.energy - Params.REST_ENERGY_COST;
        			
        			
        		}
        		
        		if(i.energy <= 0) {
    				i.alive = false;
    			}
        		
        		if(i.alive == false) {
        			dead.add(i);
        		}
        	}
        	
        	for(Critter i : dead) {
        		population.remove(i);
        	}
        	
        	for(Critter i : babies) {//puts all babies in the population
        		population.add(i);	
        	}
        	
        	babies.clear();
        	
        	for(int i = 0; i < Params.REFRESH_CLOVER_COUNT; i++) {
        		Critter p = new Clover();
        		p.alive = true;
        		p.energy = Params.START_ENERGY;
        		p.x_coord = getRandomInt(Params.WORLD_WIDTH);
        		p.y_coord = getRandomInt(Params.WORLD_HEIGHT);
        		population.add(p);
        	}
        	
        	hasMoved.clear();   	
        }

        /**
         * prints 2D grid of critter world.
         * 
         * @param nothing.
         * @return nothing.
         * 
         */
        public static void displayWorld(GridPane pane) {
        	pane.setLayoutX(Params.WORLD_WIDTH);
        	pane.setLayoutY(Params.WORLD_HEIGHT);
        	pane.setGridLinesVisible(true);
        	for(Critter i: population) {
        		if(i.viewShape() == CritterShape.CIRCLE) {
        			Path path = new Path();
        			MoveTo moveTo = new MoveTo(0.0, 2.5);
        			ArcTo arcTo = new ArcTo();
        			arcTo.setX(5.0);
        			arcTo.setY(2.5);
        			arcTo.setRadiusX(2.5);
        			arcTo.setRadiusY(2.5);
        			
        			ArcTo arcToo = new ArcTo();
        			arcToo.setX(0.0);
        			arcToo.setY(2.5);
        			arcToo.setRadiusX(2.5);
        			arcToo.setRadiusY(2.5);

        			path.getElements().add(moveTo);
        			path.getElements().addAll(arcTo, arcToo);
        			Shape shape = path;
        			colorset(i, shape);
        			pane.add(shape, i.x_coord, i.y_coord);	
        		}
        		
        		if(i.viewShape() == CritterShape.SQUARE) {
        			Path path = new Path();
        			
        			MoveTo moveTo = new MoveTo(0.0, 0.0);
        			LineTo line1 = new LineTo(0.0 , 5.0);  
        		    LineTo line2 = new LineTo(5.0 , 5.0);       
        		    LineTo line3 = new LineTo(5.0 , 0.0);
        		    LineTo line4 = new LineTo(0.0 , 0.0);
        		    path.getElements().add(moveTo); 
        		    path.getElements().addAll(line1, line2, line3, line4);
        	        Shape shape = path;
        			colorset(i, shape);
        			pane.add(shape, i.x_coord, i.y_coord);
        		}
        		
        		if(i.viewShape() == CritterShape.DIAMOND) {
        			Path path = new Path();
        			
        			MoveTo moveTo = new MoveTo(2.5, 0.0);
        			LineTo line1 = new LineTo(0.0 , 2.5);  
        		    LineTo line2 = new LineTo(2.5 , 5.0);       
        		    LineTo line3 = new LineTo(5.0 , 2.5);
        		    LineTo line4 = new LineTo(2.5 , 0.0);
        		    path.getElements().add(moveTo); 
        		    path.getElements().addAll(line1, line2, line3, line4);
        	        Shape shape = path;
        			colorset(i, shape);
        			pane.add(shape, i.x_coord, i.y_coord);
        		}
        		
        		if(i.viewShape() == CritterShape.TRIANGLE) {
 
        			Path path = new Path();
        			
        			MoveTo moveTo = new MoveTo(0.0, 0.0);
        			LineTo line1 = new LineTo(2.5 , 5.0);  
        		    LineTo line2 = new LineTo(5.0 , 0.0);       
        		    LineTo line3 = new LineTo(0.0 , 0.0);
        		    path.getElements().add(moveTo); 
        		    path.getElements().addAll(line1, line2, line3);
        	        Shape shape = path;
        	        colorset(i, shape);
        	        pane.add(shape, i.x_coord, i.y_coord);
        		}
        		
        		if(i.viewShape() == CritterShape.STAR) {
        			Path path = new Path();
        			
        			MoveTo moveTo = new MoveTo(0.0, 0.0);
        			LineTo line1 = new LineTo(2.5 , 5.0); // 
        		    LineTo line2 = new LineTo(5.0 , 0);       
        		    LineTo line3 = new LineTo(0.0 , 2.5);  
        		    LineTo line4 = new LineTo(5.0 , 2.5);   
        		    LineTo line5 = new LineTo(0.0, 0.0);  
        		       
        		    //Adding all the elements to the path 
        		    path.getElements().add(moveTo); 
        		    path.getElements().addAll(line1, line2, line3, line4, line5);  
        		            		         
        		    Shape shape = path;
        		    colorset(i, shape);
        		    pane.add(shape, i.x_coord, i.y_coord);
        		}        		
        	}        	
        }
        
        private static void colorset(Critter i, Shape shape) {
        	if(i.viewColor() != javafx.scene.paint.Color.WHITE) {
				shape.setFill(i.viewColor());
			}
			
        	if(i.viewFillColor() != javafx.scene.paint.Color.WHITE) {
				shape.setFill(i.viewFillColor());
			}
			
        	if(i.viewOutlineColor() != javafx.scene.paint.Color.WHITE) {
				shape.setFill(i.viewOutlineColor());
        	}	
        }

        /**
         * simulates the actions taken (if any) by a single critter 
         * as it goes about its life in the simulation.
         * 
         * @param nothing.
         * @return nothing.
         */
        public abstract void doTimeStep();

        /**
         * simulates the actions taken when a critter encounters an opponent.
         * 
         * @param String of opponent.
         * @return boolean value of whether or not it will fight.
         */
        public abstract boolean fight(String oponent);

        /* a one-character long string that visually depicts your critter
         * in the ASCII interface */
        public String toString() {
            return name;
        }

        /**
         * returns energy of critter.
         * 
         * @param nothing.
         * @return energy.
         */
        protected int getEnergy() {
            return energy;
        }
        	
        /**
         * simulates a critter walking in a direction.
         * moves a critter one position in a specified direction.
         * 
         * @param direction.
         * @return nothing.
         */
        protected final void walk(int direction) {
        	if(direction != 2 && direction != 6) {
        		if((direction == 0) || (direction == 1) || (direction == 7)) {
        			x_coord++;
        		}
        		
        		else if((direction > 2) && (direction < 6)) {
        			x_coord--;
        		}
        	}
        	
        	if(direction != 0 && direction != 4) {
        		if((direction > 0) && (direction < 4)) {
        			y_coord--;
        		}
        		
        		else if((direction > 4) && (direction <= 7)) {
        			y_coord++;
        		}
        	}
        	
        	energy = getEnergy() - Params.WALK_ENERGY_COST;
        	
        	//coordinates wraps around if necessary
        	if(x_coord < 0) {
        		x_coord = (Params.WORLD_WIDTH  + x_coord);
        	}
        	
        	if(y_coord < 0) {
        		y_coord = (Params.WORLD_HEIGHT + y_coord);
        	}
        	
        	x_coord = x_coord % Params.WORLD_WIDTH;
        	y_coord = y_coord % Params.WORLD_HEIGHT;
        }

        /**
         * simulates a critter running in a direction.
         * moves a critter two position in a specified direction.
         * 
         * @param direction.
         * @return nothing.
         */
        protected final void run(int direction) {
        	if(direction != 2 && direction != 6) {
        		if((direction == 0) || (direction == 1) || (direction == 7)) {
        			x_coord += 2;
        		}
        		
        		else if((direction > 2) && (direction < 6)) {
        			x_coord -= 2;
        		}
        	}
        	
        	if(direction != 0 && direction != 4) {
        		if((direction > 0) && (direction < 4)) {
        			y_coord -= 2;
        		}
        		
        		else if((direction > 4) && (direction <= 7)) {
        			y_coord += 2;
        		}
        	}
        	
        	//coordinates wraps around if necessary
        	energy = getEnergy() - Params.RUN_ENERGY_COST;
        	
        	if(x_coord < 0) {
        		x_coord = (Params.WORLD_WIDTH  + x_coord);
        	}
        	
        	if(y_coord < 0) {
        		y_coord = (Params.WORLD_HEIGHT + y_coord);
        	}
        	
        	x_coord = x_coord % Params.WORLD_WIDTH;
        	y_coord = y_coord % Params.WORLD_HEIGHT;
        }

        /**
         * simulates calling critter reproducing if it has minimum reproducing energy.
         * 
         * @param Critter offspring and direction.
         * @return nothing.
         */
        protected final void reproduce(Critter offspring, int direction) {
        	if(energy >= Params.MIN_REPRODUCE_ENERGY) {
        		offspring.alive = true; // TODO: Complete this method
        		offspring.x_coord = x_coord;
        		offspring.y_coord = y_coord;
        		offspring.walk(direction);
        		
        		if(energy % 2 == 0) {//if energy is even, divide in half b/w parent and child
        		offspring.energy = energy / 2;
        		energy = energy / 2;
        		}
        		
        		else {//if energy is odd give bigger half to child
        			offspring.energy = (energy / 2) + 1;
        			energy = energy / 2;
        		}
        		
        		offspring.name = name;
        		babies.add(offspring);
        	}
        }
        
        /**
         * Handles the encounters of two Critters (calls fight method).
         * 
         * @param Critter i and Critter j.
         * @return nothing.
         */
        private static void doEncounters(Critter i, Critter j) {
        	int savex;
        	int savey;
        	int xroll;
        	savex = i.x_coord;
        	savey = i.y_coord;
        	
        	if(i.alive == false) {// removes critter if already dead
        		population.remove(i);
        		return;
        	}
        	
        	if(j.alive == false) {//removes critter if already dead
        		population.remove(j);
        		return;
        	}
        	
        	//getting xroll for i
        	if(i.fight(j.toString()) == true) {
        		xroll = getRandomInt(i.getEnergy());
        	}
        	
        	else {
        		if(i.alive == true && (savex != i.x_coord || savey != i.y_coord)) {//checks moving preconditions and will move critter back if not correct
        			int fullflag = 0;
        			
    	    		for(Critter p : population) {
    	    			if(i.x_coord == p.x_coord && i.y_coord == p.y_coord && i.alive == true && p.alive == true && !i.equals(p)) {
    	    				fullflag = 1;
    	    			}
    	    		}
    	    		
    	    		if(hasMoved.contains(i) || fullflag == 1) {
    		    		i.x_coord = savex;
    		    		i.y_coord = savey;
    	    		}
    	    		
    	    		else {
    	    			return;
    	    		}
        		}
        		
        		if(i.alive == false) {
        			population.remove(i);
        			return;
        		}
        		
        		xroll = 0;
        	}
        	
        	//getting yroll for y
        	int yroll;
        	
        	if(j.fight(i.toString()) == true) {
        		yroll = getRandomInt(j.getEnergy());
        	}
        	else {
        		if(j.alive == true && (savex != j.x_coord || savey != j.y_coord)) {//checks moving preconditions and will move critter back if not correct
        			int fullflag = 0;
        			
    	    		for(Critter p : population) {
    	    			if(j.x_coord == p.x_coord && j.y_coord == p.y_coord && j.alive == true && p.alive == true) {
    	    				fullflag = 1;
    	    			}
    	    		}
    	    		
    	    		if(hasMoved.contains(j) || fullflag == 1) {
    		    		j.x_coord = savex;
    		    		j.y_coord = savey;
    	    		}
    	    		
    	    		else {
    	    			return;
    	    		}
        		}
        		
        		if(j.alive == false) {
        			population.remove(j);
        			return;
        		}
        		
        		yroll = 0;
        	}
        	
        	// checks for higher roller. winner gets half loser's energy and A wins if there is a tie
        	if(xroll >= yroll) {
        		i.energy = i.energy + (j.energy / 2);
        		population.remove(j);
        	}
        	else {
        		j.energy = j.energy + (i.energy / 2);
        		population.remove(i);
        	}  	
        }

        /**
         * The TestCritter class allows some critters to "cheat". If you
         * want to create tests of your Critter model, you can create
         * subclasses of this class and then use the setter functions
         * contained here.
         * <p>
         * NOTE: you must make sure that the setter functions work with
         * your implementation of Critter. That means, if you're recording
         * the positions of your critters using some sort of external grid
         * or some other data structure in addition to the x_coord and
         * y_coord functions, then you MUST update these setter functions
         * so that they correctly update your grid/data structure.
         */
        static abstract class TestCritter extends Critter {

        	/**
             * sets Critter energy.
             *
             * @param new_energy_value.
             * @return nothing.
             */
            protected void setEnergy(int new_energy_value) {
                super.energy = new_energy_value;
            }
            
            /**
             * sets Critter alive status.
             *
             * @param new_life.
             * @return nothing.
             */
            protected void setAlive(boolean new_life) {
                super.alive = new_life;
            }
            
            /**
             * sets Critter name.
             *
             * @param name.
             * @return nothing.
             */
            protected void setName(String name) {
            	super.name = name;	
            }

            /**
             * sets x coordinate.
             *
             * @param new_x_coord.
             * @return nothing.
             */
            protected void setX_coord(int new_x_coord) {
                super.x_coord = new_x_coord;
            }

            /**
             * sets y coordinate.
             *
             * @param new_y_coord.
             * @return nothing.
             */
            protected void setY_coord(int new_y_coord) {
                super.y_coord = new_y_coord;
            }

            /**
             * gets x coordinate.
             *
             * @param nothing.
             * @return x_coord.
             */
            protected int getX_coord() {
                return super.x_coord;
            }

            /**
             * gets y coordinate.
             *
             * @param nothing.
             * @return y_coord.
             */
            protected int getY_coord() {
                return super.y_coord;
            }
            
            /**
             * gets life status.
             *
             * @param nothing.
             * @return boolean of whether or not critter is alive.
             */
            protected boolean getLife() {
            	return super.alive;
            }
            
            /**
             * gets name.
             *
             * @param nothing.
             * @return name.
             */
            protected String getName() {
            	return super.name;
            }

            /**
             * This method getPopulation has to be modified by you if you
             * are not using the population ArrayList that has been
             * provided in the starter code.  In any case, it has to be
             * implemented for grading tests to work.
             */
            protected static List<Critter> getPopulation() {
                return population;
            }

            /**
             * This method getBabies has to be modified by you if you are
             * not using the babies ArrayList that has been provided in
             * the starter code.  In any case, it has to be implemented
             * for grading tests to work.  Babies should be added to the
             * general population at either the beginning OR the end of
             * every timestep.
             */
            protected static List<Critter> getBabies() {
                return babies;
            }
        }
    }
