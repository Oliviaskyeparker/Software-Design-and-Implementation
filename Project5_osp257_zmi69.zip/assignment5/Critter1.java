/*
 * CRITTERS Critter1.java
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 1
 * Fall 2021
 */

package assignment5;

import java.util.List;

import assignment5.Critter.CritterShape;

/*
 * Walker, always walks when encounter other critters. 
 * Every timestep it walks in a random direction. 
 * The runStats method prints out the number of alive Critter1s.
 */
public class Critter1 extends Critter {
	
	private int dir;

	/**
	 * Constructor initializes private variable.
	 * 
	 * @param nothing.
	 * @return nothing. 
	 */
    public Critter1() {
        dir = Critter.getRandomInt(8);
    }
    
    /**
	 * Critter moves in a random direction every timestep.
	 * 
	 * @param String of opponent.
	 * @return false. 
	 */
    public boolean fight(String opponent) {
    	walk(getRandomInt(8));
        
    	return false;
    }

    /**
	 * Critter moves in a random direction when encountering an opponent.
	 * 
	 * @param nothing.
	 * @return nothing. 
	 */
    @Override
    public void doTimeStep() {
        /* take one step forward */
    	while(look(dir, false) != null) {
    		 dir = (dir + 1) % 8;
       }
    	
    	walk(dir);
    	dir = (dir + 1) % 8;//change direction
    }
    
    /**
     * returns name of critter.
     * 
	 * @param nothing.
	 * @return 1. 
	 */
    @Override
    public String toString() {
        return "1";
    }

    /**
	 * @param critter1s (list of all alive critter1s).
	 * @return the number of alive Critter1s in a sentence.
	 */
    public static String runStats(List<Critter> critter1s) {
    	return "There are " + critter1s.size() + " Critter1s";
    }

	@Override
	public CritterShape viewShape() {
		return CritterShape.STAR;
	}
	
	@Override
	public javafx.scene.paint.Color viewOutlineColor() {
		return javafx.scene.paint.Color.BLACK;
	}
	
	@Override
	public javafx.scene.paint.Color viewFillColor() {
		return javafx.scene.paint.Color.PINK;
	}
}
