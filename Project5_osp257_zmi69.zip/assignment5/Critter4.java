/*
 * CRITTERS Critter4.java
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 1
 * Fall 2021
 */

package assignment5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import assignment5.Critter.CritterShape;


/*
 * Memory Critter stores memories of people they fight and always fights. 
 * Every timestep, it runs upward. The runStats method prints 
 * out the number of alive Critter4s, and the number of
 * different critters that the critter4s have fought.
 */
public class Critter4 extends Critter {
	
	private static ArrayList<String> opponents = new ArrayList<String>();
	
   /**
    * every timestep the critter runs upward.
    * 
    * @param nothing. 
    * @return nothing.
    */
    @Override
    public void doTimeStep() {
        run(2);
    }
    
    /**
     * adds opponent to opponents list.
     * 
     * @param string of opponent. 
     * @return true.
     */
    @Override
    public boolean fight(String opponent) {
    	opponents.add(opponent);
        
    	return true;
    }
    
    /**
     * returns name of the critter.
     * 
     * @param nothing. 
     * @return 4.
     */
    public String toString() {//returns name of critter
        return "4";
    }
    
    /**
     * @param critter4s (list of critter4s).
     * @return the number of critter4s, as well as number of the different critters
     * they fought in a sentence.
    */
    public static String runStats(List<Critter> critter4s) {//prints list and number of opponents faced
    	Map<String, Integer> critter_count = new HashMap<String, Integer>();
    	
    	for(Critter crit : critter4s) {
    		for(String opponent : ((Critter4) crit).opponents) {
                critter_count.put(opponent, critter_count.getOrDefault(opponent, 0) + 1);
    		}
    	}
    	
    	String runStatsStr = "There are " + critter4s.size() + " Critter4s \n";
    	
    	if(!critter4s.isEmpty()) {
    		runStatsStr += "These Critters fought " + opponents.size() + " opponents as follows: \n ";
    		
        	String prefix = "";
        	
        	for (String s : critter_count.keySet()) {
                runStatsStr += prefix + s + ":" + critter_count.get(s);
                prefix = ", ";
            }
        }
    	
    	return runStatsStr;
    }

	@Override
	public CritterShape viewShape() {
		return CritterShape.SQUARE;
	}
	
	@Override
	public javafx.scene.paint.Color viewFillColor() {
		return javafx.scene.paint.Color.BLUE;
	}
	
	@Override
	public javafx.scene.paint.Color viewOutlineColor() {
		return javafx.scene.paint.Color.GREEN;
	}
}
