/*
 * CRITTERS Critter3.java
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 1
 * Fall 2021
 */

package assignment5;

import java.util.List;

import assignment5.Critter.CritterShape;

/*
 * Reproducer, reproduces when it encounters other critters and has enough energy.
 * Every timestep it walks in a random direction. The runStats method prints 
 * out the number of alive Critter3s, the number of Critter3s that are parents,
 * and the number of non-parents.
 */
public class Critter3 extends Critter {

    private int dir;
    private boolean parent;
    
    /**
	 * Constructor initializes private variables.
	 * 
	 * @param nothing.
	 * @return nothing. 
	 */
    public Critter3() {
        dir = Critter.getRandomInt(8);
        parent = false;
    }

    /**
	 * Critter reproduces when encountering an opponent.
	 * 
	 * @param String of opponent.
	 * @return false. 
	 */
    public boolean fight(String opponent) {
    	Critter3 child = new Critter3();
    	
    	if(this.getEnergy() >= Params.MIN_REPRODUCE_ENERGY) {
    		reproduce(child, Critter.getRandomInt(8));
    		parent = true;
    	}
    	
        return false;
    }

    /**
	 * Critter moves in a random direction when encountering an opponent.
	 * 
	 * @param nothing.
	 * @return nothing. 
	 */
    @Override
    public void doTimeStep() {
        /* take one step forward */
        walk(dir);
        dir = (dir + 1) % 8;
    }
    
    /**
     * returns name of critter.
     * 
	 * @param nothing.
	 * @return 3. 
	 */
    @Override
    public String toString() {
        return "3";
    }

    /**
	 * @param critter3s (list of all critter1s).
	 * @return the number of alive Critter3s, the number of Critter3s that are parents,
     * and the number of non-parents in a sentence.
	 */
    public static String runStats(List<Critter> critter3s) {
    	
        int parentCritter = 0;
        
        for(Critter crit : critter3s) {
        	if(((Critter3) crit).parent) {
        		parentCritter++;
        	}
        }
        
        String runStatsStr = critter3s.size() + " Critter3s as follows: \n";
        runStatsStr += "Parent Critter3: " + parentCritter + "\n";
       
        runStatsStr += "Non-parent Critter3: " + (critter3s.size() - parentCritter) + "\n";  
        
        return runStatsStr;
    }

	@Override
	public CritterShape viewShape() {
		// TODO Auto-generated method stub
		return CritterShape.TRIANGLE;
	}
	@Override
	public javafx.scene.paint.Color viewFillColor(){
		return javafx.scene.paint.Color.BLUE;
	}
}
