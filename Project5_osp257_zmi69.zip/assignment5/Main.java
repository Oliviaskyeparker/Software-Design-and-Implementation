/* CRITTERS GUI <Main.java>
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 1
 * Fall 2021
 */

/*
   Describe here known bugs or issues in this file. If your issue spans multiple
   files, or you are not sure about details, add comments to the README.txt file.
 */
package assignment5;

import java.util.*;
import java.io.*;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.Scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.collections.*;
import javafx.animation.*;

public class Main extends Application {
	private static List<String> critterClassNames = new ArrayList<String>();
	private static List<String> fileNames = new ArrayList<String>();
	private int stepCount = 1;
	private int seedCount = 0;
	private int createCount = 1;
	private boolean showing = false;
	private boolean statsDisplayed = false;
	private String critterForStats = "";
	private boolean animationStarted = false;
	private int framesPerSec = 0;
	
	private static String myPackage; // package of Critter file.

    /* Critter cannot be in default pkg. */
    static {
        myPackage = Critter.class.getPackage().toString().split(" ")[1];
    }
    
    /**
     * Sets up all the components in Critter.
     * 
     * @param primaryStage.
     * @return nothing.
     */
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		GridPane pane = new GridPane();
		
		GridPane critterWorld = new GridPane();
		critterWorld.setPrefHeight(Params.WORLD_HEIGHT);
		critterWorld.setPrefWidth(Params.WORLD_WIDTH);
		critterWorld.setMaxWidth(Params.WORLD_WIDTH);
		critterWorld.setMaxHeight(Params.WORLD_HEIGHT);
		
		BorderPane root = new BorderPane();
		
		BorderPane topRoot = new BorderPane();
		
		Scene gameScene;
		
		Button quit = new Button("quit");
		quit.setPrefWidth(50);
		
		Button show = new Button("show");
		show.setPrefWidth(50);
		
		Button step = new Button("step");
		step.setPrefWidth(50);
		
		Button seed = new Button("seed");
		seed.setPrefWidth(50);
		
		Button stats = new Button("stats");
		stats.setPrefWidth(50);
		
		Button clear = new Button("clear");
		clear.setPrefWidth(50);
		
		Button create = new Button("create");
		create.setPrefWidth(50);
		
		Button animation = new Button();
		animation.setText("Start/Stop");
		animation.setPrefWidth(90);
		
		TextField seedText = new TextField();
		seedText.setPromptText("seed");
		seedText.setMaxWidth(50);
		
		TextField createText = new TextField();
		createText.setPromptText("create");
		createText.setMaxWidth(50);
		
		TextField stepText = new TextField();
		stepText.setPromptText("step");
		stepText.setMaxWidth(50);
		
		ComboBox<String> critters = new ComboBox<String>(FXCollections.observableArrayList(critterClassNames));
		critters.setPromptText("critter type");
		
		HBox createRow = new HBox();
		createRow.getChildren().addAll(createText, create);
		
		HBox seedRow = new HBox();
		seedRow.getChildren().addAll(seedText, seed);
		
		HBox stepRow = new HBox();
		stepRow.getChildren().addAll(stepText, step);
		
		HBox topScreen = new HBox();
		topScreen.getChildren().addAll(critters, stats, show, clear, quit);
		topScreen.setSpacing(2);
		
		HBox secondRow = new HBox();
		secondRow.setSpacing(2);
		secondRow.getChildren().add(createRow); 
		
		Label statsLabel = new Label();
		
		//set on action for buttons
		quit.setOnAction(event -> {
			System.exit(0);
		});
		
		show.setOnAction(event -> {
			Critter.displayWorld(critterWorld);
			critterWorld.setGridLinesVisible(true);
			root.setCenter(critterWorld);

			showing = true;

			if(statsDisplayed) {
				updatingStats(critterForStats, statsLabel);
				topRoot.setRight(statsLabel);
			}

		});
		
		seed.setOnAction(event -> {
			if ((seedText.getText() != null && !seedText.getText().isEmpty())) {
	            try {
	            	seedCount = Integer.parseInt(seedText.getText());
	            } catch(Exception e) {
	            	seedCount = 0;
	            }
	        }
			
			seedText.setText("");
			Critter.setSeed(seedCount);
		});
		
		create.setOnAction(event -> {
			if((critters.getValue() != null) && !critters.getValue().toString().isEmpty()) {
				if((createText.getText() != null) && !createText.getText().isEmpty()) {
					try {
						createCount = Integer.parseInt(createText.getText());
					} catch(Exception e) {
						createCount = 1;
					}
				}
				
				for(int i = 0; i < createCount; i++) {
					try {
        				Critter.createCritter(critters.getValue().toString());
        			} catch (Exception e) {
        				break;
        			}	
				}
				
				createText.setText("");
				createCount = 1;
				
				if(showing) {
					Critter.displayWorld(critterWorld);
				}

				if(statsDisplayed) {
					updatingStats(critterForStats, statsLabel);
					topRoot.setRight(statsLabel);
				}
			}
		});
		
		clear.setOnAction(event -> {
			Critter.clearWorld();

			if(showing) {
				Critter.displayWorld(critterWorld);
			}
			
			if(statsDisplayed) {
				updatingStats(critterForStats, statsLabel);
				topRoot.setRight(statsLabel);
			}
		});
		
		step.setOnAction(event -> {
			if((stepText.getText() != null) && !stepText.getText().isEmpty()) {
				try {
					stepCount = Integer.parseInt(stepText.getText());
				} catch(Exception e) {
					stepCount = 1;
				}
			}
			
			for(int i = 0; i < stepCount; i++) {
				Critter.worldTimeStep();
			}
			
			stepCount = 1;
			stepText.setText("");
			
			if(showing) {
				Critter.displayWorld(critterWorld);
				critterWorld.setGridLinesVisible(true);
			}
			
			if(statsDisplayed) {
				updatingStats(critterForStats, statsLabel);
				topRoot.setRight(statsLabel);
			}
		});
		
		stats.setOnAction(event -> {
			if((critters.getValue() != null) && !critters.getValue().toString().isEmpty()) {
				critterForStats = critters.getValue().toString();
				updatingStats(critterForStats, statsLabel);
				topRoot.setRight(statsLabel);
				statsDisplayed = true;
			}
		});
		
		AnimationTimer timer;
		HBox animBox = new HBox();
	
		TextField frames = new TextField();
		frames.setPromptText("frames per second");
		frames.setMaxWidth(116);
		
		timer = new AnimationTimer() {
			
			@Override
			public void handle(long now) {	
				for(int i = 0; i < framesPerSec; i++) {
					Critter.worldTimeStep();
				}
				
				Critter.displayWorld(critterWorld);
				
				if(statsDisplayed) {
					updatingStats(critterForStats, statsLabel);
					topRoot.setRight(statsLabel);
				}
			}
		};
			      
		animation.setOnAction(event -> {
			create.setVisible(animationStarted);
	    	createText.setVisible(animationStarted);
	    	
			if ((frames.getText() != null && !frames.getText().isEmpty())) {
	            try {
	            	framesPerSec = Integer.parseInt(frames.getText());
	            } catch(Exception e) {
	            	framesPerSec = 1;
	            }
	        }
			else {
				framesPerSec = 1;
			}
			
		    if (animationStarted) {
		    	timer.stop();
		    } else {
		    	timer.start();
		    }
		    
		    animationStarted = !animationStarted;
		    frames.setText("");
		});
		
		
		animBox.getChildren().addAll(frames, animation);
		secondRow.getChildren().add(animBox);
		pane.add(topScreen, 0, 0);
		pane.add(secondRow, 0, 1);
		pane.add(stepRow, 0, 3);
		pane.add(seedRow, 0, 5);
		topRoot.setLeft(pane);
		topRoot.setRight(statsLabel);
		root.setTop(topRoot);
		
		gameScene = new Scene(root, 310, 250);
		primaryStage.setTitle("Critter Game");
		primaryStage.setScene(gameScene);
		primaryStage.show();
	}
	
    public static void main(String[] args) {
        getClassNames();
        launch(args);
    }
    
    /**
     * gets critter classes' names.
     * @param nothing.
     * @return nothing.
     */
    private static void getClassNames() {
    	File[] files = new File("src/" + myPackage).listFiles(new FilenameFilter() {
    		@Override
    		public boolean accept(File dir, String name) {
    			return name.endsWith(".java");                     
    			}
    		});
        

    	for (File file : files) {
    	    if (file.isFile()) {
    	    	String fileName = file.getName().split("\\.")[0];
    	        fileNames.add(fileName);
    	    }   
    	}
    	
    	for(String fileName : fileNames) {//check if file contains valid Critter class
    		String critterName = myPackage + "." + fileName;
    		
    		try {
    			Critter critter = (Critter) Class.forName(critterName).newInstance();
    		} catch (Exception e) {
    			continue;
    		} 
    		
    		critterClassNames.add(fileName);
    	}	
    }
    
    /**
     * Update stats for critters.
     * 
     * @param critters.
     * @param statsLabel.
     * @return nothing.
     */
    private void updatingStats(String critters, Label statsLabel) {
    	try {
			Object critter = Class.forName(myPackage + "." + critters).newInstance();
			List<Critter> critterList = Critter.getInstances(critters);
			Method runStats = critter.getClass().getMethod("runStats", List.class);
			statsLabel.setText((String) runStats.invoke(critter, critterList));
		} catch (Exception e) {
			System.out.println("Error");
		}
    }
}
