/*
 * CRITTERS Critter2.java
 * EE422C Project 5 submission by
 * Olivia Parker
 * osp257
 * 17805
 * Zulima Ike
 * zmi69
 * 17805
 * Slip days used: 1
 * Fall 2021
 */

package assignment5;

import java.util.List;

import assignment5.Critter.CritterShape;

/*
 * Angry critter only fights critter 3. If facing any other type of critter, it will look to see if the space 
 * to the left is occupied, and will run if it is open, and fight if the space is occupied.
 * Every timestep it walks forward. The runStats method prints the number of alive Critter2s.
 */
public class Critter2 extends Critter {
		
	/** 
	 * every timestep the critter walks right.
	 * 
     * @param nothing.
     * @return nothing.
     */
    @Override
    public void doTimeStep() {//walks to the right every step
        walk(0);
    }
    
    /**
     * critter will fight only opponent 3, otherwise will run left.
     * 
     * @param String of opponent. 
     * @return false if opponent is not 3, true if opponent is 3.
     */
    @Override
    public boolean fight(String opponent) {//only fights if opponent is 3
        if(!opponent.equals("3")) {
        	if(look(4, true) == null) {
        		run(4);
        		return false;
        	}
        	else {
        		return true;
        	}
        }
        
        return true;
    }
    
    /**
     * returns name of critter.
     * 
     * @param nothing. 
     * @return 2.
     */
    public String toString() {//returns name of the critter
        return "2";
    }

    /** 
     * @param critter2s (list of all critter2s).
     * @return the number of alive Critter2s in a sentence.
     */
    public static String runStats(List<Critter> critter2s) {//prints statistics of critter2
    	return "There are " + critter2s.size() + " Critter2s";
    }

	@Override
	public CritterShape viewShape() {
		return CritterShape.DIAMOND;	
	}
	
	@Override
	public javafx.scene.paint.Color viewOutlineColor() {
		return javafx.scene.paint.Color.PURPLE;
	}
	
	@Override
	public javafx.scene.paint.Color viewFillColor() {
		return javafx.scene.paint.Color.GREY;
	}
}
